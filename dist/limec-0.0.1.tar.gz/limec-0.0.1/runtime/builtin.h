int rand();
void print(int x);
int getArg(int index);
extern int argc;
extern char ** argv;